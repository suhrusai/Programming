class Sumofprimes{
    public static void main(String[] args) {
         int a[]=new int[10];
         int sum=0;
         for(int i=0;i<10;i++)
         {
             a[i]=Integer.parseInt(args[i]);
             boolean prime=true;
             for(int j=2;j<a[i];j++)
                if(a[i]%j==0)
                    prime=false;
                if(prime==true)
                    sum=sum+a[i];
         }
         System.out.println("Sum="+sum);
    }
}