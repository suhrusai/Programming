class Factorial{
public static void main(String[] args) {
        long fact[]=new long[40];
        for(int j=0;j<40;j++)
        {
            fact[j]=1;
            for(int i=2;i<=j;i++)
                fact[j]=fact[j]*i;
        }
        for (int i=0;i<args.length;i++) {
            for(int j=0;j<40;j++){
                System.out.println(fact[j]);
                if(Long.parseLong(args[i])==fact[j])
                    System.out.println(args[i]);
                    return ;
            }

        }
}
}