class Prime{
    public static void main(String[] args) {
        int a=Integer.parseInt(args[0]);
        //int root = int(Math.sqrt(a)) ;
        boolean check=true;
   for(int i=2; i<a; i++) 
   {
      if(a%i == 0)
          check=false;
   }
   if(check==false)
        System.out.println("Not a prime");
    else 
        System.out.println("Prime");
    }
}