import java.util.Scanner;
class user{
    String[] s={"Access Phone contacts","Uses your phone's location","Access of Gallery"};
    public void user_settings(String name){
        if(name.equals("Suresh"))
            System.out.println("Your settings are: "+s[0]+","+s[1]+","+s[2]);
        else if(name.equals("Ramesh"))
            System.out.println("Your settings are: "+s[0]);
    }
}
class Car{
    public static void main(String[] args) {
        Scanner scan= new Scanner(System.in);
        System.out.print("Who entered the car? ");
        String person_entered=scan.nextLine();
        System.out.println("Welcome "+person_entered+".Your phone is paired now:");
        user ref=new user();
        ref.user_settings(person_entered);
    }
}