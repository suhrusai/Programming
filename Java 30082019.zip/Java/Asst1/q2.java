import java.util.Scanner;
class user
{
    private int PIN;
    String Name;
    String expiry;
    int balance;
    user(String Name,String exp,int balance){
        this.Name=Name;
        this.balance=balance;
        this.expiry=exp;
    }
    void set_pin(int PIN)
    {
        this.PIN=PIN;
    }
    boolean check_pin(int entered_pin) 
    {
           return entered_pin==PIN;
    }
    boolean expiry(String today){
    if((Integer.parseInt(expiry.substring(0,2))<Integer.parseInt(today.substring(0,2)) && Integer.parseInt(today.substring(3,5))==Integer.parseInt(expiry.substring(3,5))) || Integer.parseInt(today.substring(3,5))>Integer.parseInt(expiry.substring(3,5))){
        System.out.println("ATMExpiredException. Please visit your bank");
        return false;
        }
        return true;
    }
    int withdraw(user ref,int cash){
        Scanner scan=new Scanner(System.in);
        if(expiry("08/08")){
        System.out.print("Enter the amount to withdraw: ");
        int amount=scan.nextInt();
        if(ref.balance-amount<0)
        {
            System.out.println("LowBankBalanceException");
        }
        else if(cash-amount<=0)
        {
            System.out.println("NoCashInATMException");
        }
        else{
            ref.balance=ref.balance-amount;
            cash=cash-amount;
            System.out.println("Collect cash...\nCurrent Balance "+ref.balance);
        }
        
    }
    return cash;
   }
}
class ATM{
    public static void main(String[] args) {
        int cash=1000;
        System.out.print("User name: ");
        Scanner scan=new Scanner(System.in);
        String name=scan.nextLine();
        System.out.print("Enter PIN:");
        user ref=new user("Sanjay","07/08",1000),ref2;
        ref.set_pin(1234);
        user ref1=new user("Rajesh","09/09",10002);
        ref1.set_pin(9912);
        if(name.equals("Sanjay"))
        {
            ref2=ref;
        }
        else
        {
            ref2=ref1;
        }
        if(ref2.check_pin(scan.nextInt())){
            ref2.withdraw(ref2,cash);}
        else{
        System.out.println("InvalidPINException.Retry again");}
       }
}