import java.util.Scanner; 
class user
{
	String a, b, c, d;
	int e;
user(int e)
{
	this.e=e;
}	
void display()
{
	a="Access phone contacts";
	b="Access gallery";
	c="Uses your phone location";
	if(e==1){
	System.out.println("Your settings: " + a + " , " + b + " , " + c);
	}
	if(e==2){
	System.out.println("Your settings: " + a );
	}
}
}
class Main
{
	public static void main(String args[])
	{
		Scanner in = new Scanner(System.in);
		String s = in.nextLine();
		System.out.println("Who entered the car?"+s);
		if(in.nextLine()=="suresh")
		{
		System.out.println("Welcome Suresh. Your phone is paired now.");
		user n = new user(1);
		n.display();
		}
		if(in.nextLine()=="ramesh")
		{
		System.out.println("Welcome Ramesh. Your phone is paired now.");
		user n = new user(2);
		n.display();
		}
	}
}