import java.util.Scanner;
import java.util.*;
interface Report{
	String[] TakeNotes();
	String[] Photos();
	String[] SubmitBill(Hall hall_obj);
}
class Hall{
	private static Hall hall_obj;
    final int Capacity=200;
    Event slots[]={null,null,null,null,null,null};
    String branch;
    int cost;
    String location;
    private Hall(/*int Capacity,String branch,int cost,String location*/){
     /*this.Capacity=Capacity;
     this.branch=branch;
     this.cost=cost;
     this.location=location;*/
	}
	public static Hall getInstance(){
		if (hall_obj == null)
			hall_obj = new Hall();
		return hall_obj;
	}
    boolean check_availability(int slot){
			if(slots[slot]==null)
				return true;
			return false;
	}
    void book_slot(Event x, int slot,int no_of_slots){
		for(int j=0;j<no_of_slots;j++)
			slots[slot+j]=x;
    }
    public void Display(Hall a){
	System.out.println("Capacity="+a.Capacity);
	System.out.println("slots="+a.slots);
	System.out.println("Branch="+a.branch);
	System.out.println("Cost=Rs."+a.cost);
	System.out.println("Location="+a.location);
    }

 
}
class Faculty{
	String Name;
	String branch;
	int slots[];
	String past_events[];
	Faculty(String Name,String branch,int slots[],String past_events[]){
	this.Name=Name;
	this.branch=branch;
	this.slots=slots;
	this.past_events=past_events;
	}
	int check_availability(Hall hall_obj,int no_of_slots){
		int i;
		boolean check=true;
			for(i=0;i<6-no_of_slots;i++)
		{
			check=true;
			for(int j=0;j<no_of_slots;j++)
				if(slots[i+j]!=1 || !hall_obj.check_availability(i+j))
				{
					check=false;
				}
			if(check==false)
				continue;
			else
				return i;
		}
			return -1;
		}   
    	void book_slot(Event x,Hall hall_obj,int no_of_slots){
		int check;
		check=check_availability(hall_obj,no_of_slots);
		if(check==-1)
			System.out.println("booking not possible ");
		else
		{
			int j;
			for(j=0;j<no_of_slots;j++)
			slots[j+check]=0;
			hall_obj.book_slot(x,check,no_of_slots);
			System.out.print("Booking done in slots: ");
			for(j=0;j<no_of_slots;j++)
				System.out.print((j+check+1)+" ");
		}
    }
    void Display(Faculty a){
	System.out.println("Name="+a.Name);
	System.out.println("Branch="+a.branch);
	System.out.println("slots="+a.slots);
	for(int i=0;i<a.past_events.length;i++)
	{
		System.out.println("Past event "+(i+1)+" "+a.past_events[i]);
	}
    }

}
abstract class Event implements Report{
	String name;
	String Resource_person;
	String Designation;
	int event_slot[];
	String photos[];
	Event(String name,String Resource_person,String Designation,int event_slot[],String photos[]){
	this.name=name;
	this.Resource_person=Resource_person;
	this.Designation=Designation;
	this.event_slot=event_slot;
	this.photos=photos;
	}
	public String[] TakeNotes(){
		String[] a={"These are ","Notes"};
		return a;
		}
	public String[] SubmitBill(Hall hall_obj){
		int c=0;
		String[] fee=new String[3];
		fee[0]="Base Price: Rs."+300;
		for(int i:event_slot)
			if(i!=0)
				c++;
		fee[1]="Cost for time: Rs."+hall_obj.cost*c;

		fee[2]="Special Charges: Rs."+500;
		return fee;
	}
	public String[] Photos(){
		return photos;
	}
	void Report(){
        }   
    int bill(){
    return 0;	
    }
    void Display(Techtalk a){
	System.out.println("Name="+a.name);
	System.out.println("Resourse person="+a.Resource_person);
	System.out.println("Designation "+a.Designation);
	System.out.println("Event slot "+a.event_slot);   
	for(int i=0;i<a.photos.length;i++){
		System.out.println(a.photos[i]);
    }
	}
}
class GuestLecture extends Event{
	GuestLecture(String name,String Resource_person,String Designation,int event_slot[],String[] photos){
		super(name,Resource_person,Designation,event_slot,photos);
	}
}
class VasaviTalkies extends Event{
	VasaviTalkies(String name,String Resource_person,String Designation,int event_slot[],String[] photos){
		super(name,Resource_person,Designation,event_slot,photos);
	}
}
class Techtalk extends Event{
	Techtalk(String name,String Resource_person,String Designation,int event_slot[],String[] photos){
		super(name,Resource_person,Designation,event_slot,photos);
	}
}
class Hallbooking{
    public static void main(String[] args) {
		
	/*create_hall(200,"EEE",200,"EEE block");*/
	Hall hall_obj=Hall.getInstance();
	hall_obj.branch="CSE";
	hall_obj.cost=200;
	hall_obj.location="Ramanujan Block";
	String past_events[]={"AI","Java"};
	int fac_avalibility[]={0,1,1,1,1,1};
 	Faculty shasi= new Faculty("Shasi","CSE",fac_avalibility,past_events);
	String photos[]={"C:/jpeg.jpeg","C:/jpeg1.jpeg","C:/jpeg2.jpeg"};
	int event_slot[]={0,1,1,0,0,0};
	Techtalk AI=new Techtalk("AI","Somebody","Professor",event_slot,photos); 
	System.out.println("\nHall details:\n"); 
	hall_obj.Display(hall_obj);
	System.out.println("\nFaculty details:\n"); 
	shasi.Display(shasi);
	System.out.println("\nEvent details:\n"); 
	AI.Display(AI);
	System.out.print("Booking status: ");
	shasi.book_slot(AI,hall_obj,4); 
	System.out.println();  
	for(int i=0;i<6;i++)
		System.out.print(shasi.slots[i]+" ");
    }

    
}
