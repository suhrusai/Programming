class Program{
    public static void main(String args[])
    {
        int a=Integer.parseInt(args[0]);
        int b=Integer.parseInt(args[1]);
        int c=Integer.parseInt(args[2]);
        if ((a > b) && (b > c)){
        System.out.println("The sorted numbers are " + a + " " + b + " " + c);
        }
    if ((a > b) && (b < c)){
        System.out.println("The sorted numbers are " + a + " " + c + " " + b);
        }
    if ((a < b) && (b < c)){
        System.out.println("The sorted numbers are " + c + " " + b + " " + a);
        }
    if ((a < b) && (b > c)){
        System.out.println("The sorted numbers are " + b + " " + a + " " + c);
       }
    }

}
