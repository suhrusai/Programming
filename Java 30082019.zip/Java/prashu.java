class ass1 
{

	public static void main(String[] args) 
	{
		String teamName[] = {"CSK","SRH","DC","MI","RCB","KKR","KXIP","RR"};
		String schedule[][] = new String[8][8];
		int teamLastMatch[] = new int[8];
		int i, j, day = 1, month = 4,count=0;
		for(i = 0; i < 8; i++)
		{
			count = 0;
			for(j = 0; j < 8; j++)
			{
				
				if(i == j)
				{
					schedule[i][j] = " ";
				}
				else
				{
					if(day-teamLastMatch[i] < 2 || day-teamLastMatch[j] < 2 )
					{
						day++;
					}
					schedule[i][j] = day +"."+month;count++;
					teamLastMatch[i]= day;
                    teamLastMatch[j]= day;
					if (count == 2)
					{
						count = 0;
						day++;
					}
					if(day>30)
					{
						month++;
						day = 1;
					}
					
					
					
				}
				
			}
		}
		System.out.print("\t");
		for(i = 0; i < 8; i++)
		{
			System.out.print(teamName[i]+"\t");
		}
		System.out.println();
		for(i = 0; i < 8; i++)
		{
			System.out.print(teamName[i]+"\t");
			for(j = 0; j < 8; j++)
			{
				System.out.print(schedule[i][j]+"\t");
			}
			System.out.println();
		}
	}

}