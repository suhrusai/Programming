final class Final_main{
    final static void method(){
        System.out.println("Method over loading not possible");
    }
    public static void main(String[] args) {
        final float pi=3.14f;
        method();
        System.out.println("pi value="+pi+", Inheritance prevented for this class");

    }
}