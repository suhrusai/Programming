class hide{
    private String password;
    hide(String password){
        this.password=password;
    }
    public void set_password(String password){
        this.password=password;
        System.out.println("Change done!!");
    }
    public void check_password(String entered_password) {
        if(password.equals(entered_password))
            System.out.println("Correct password");
        else{
            System.out.println("Wrong password");
        }
    }
}
class Main_hiding{
    public static void main(String[] args) {
    hide pass= new hide(args[0]);
    pass.set_password(args[1]);
    pass.check_password(args[2]);
    }
}