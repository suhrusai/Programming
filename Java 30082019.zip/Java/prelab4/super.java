interface sum {
    int sum_two(int x,int y);
}
abstract class add implements sum {
    public static add create(){
        add ref= new sub_class();
        return ref;
    }
}
    class sub_class extends add{
    public int sum_two(int x,int y) {
        return x+y;
    }
  }
class main {
    public static void main(String[] args) {
        sum ref= add.create();
        System.out.println("Sum of 1+2="+ref.sum_two(1,2));
    }
}