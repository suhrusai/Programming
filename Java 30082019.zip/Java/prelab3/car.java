import java.util.Scanner;
class Car{
    String Fuel;
    String Gb;
    int Auto;
    int seating;
    int CC;
    Car(String Fuel,String Gb,int Auto,int seating,int cc){
        this.Fuel=Fuel;
        this.Gb=Gb;
        this.Auto=Auto;
        this.seating=seating;
        this.CC=CC;
    }
    public void Carignition()
    {

    }
    public void CarMilage(int dist,int consumed_fuel){
        System.out.println("Milage="+ dist/consumed_fuel);
    }
    public void CarMaintainance(int yrs){
        if(yrs>2)
            System.out.println("Maintainance required!!");
        else
            System.out.println("Maintainance not Required");
    }
}
class CarMain{
    public static void main(String[] args) {
        
    
    Scanner scan=new Scanner(System.in);
    System.out.println("Enter fuel type,Gearbox,Automatic(Y/N),Seating,cc:");
    Car car=new Car(scan.nextLine(),scan.nextLine(),scan.nextInt(),scan.nextInt(),scan.nextInt());
    System.out.println("Enter distance and fuel consumed");
    car.CarMilage(scan.nextInt(),scan.nextInt());
    System.out.println("Number of Years:");
    car.CarMaintainance(scan.nextInt());
}
}