class main{
    public int add(int a, int b){
        return a+b;
    }
    public int add(int a, int b, int c) {
        return a+b+c;
    }
    public int add(int a,int b,int c,int d) {
        return a+b+c+d;   
    }
    public static void main(String[] args) {
        main obj= new main();
        int[] a=new int[args.length];
        for(int i=0;i<args.length;i++){
            a[i]=Integer.parseInt(args[i]);
        }
        if(a.length==2)
            System.out.println(obj.add(a[0],a[1]));
        else if(a.length==3)
            System.out.println(obj.add(a[0],a[1],a[2]));
        else if(a.length==4)
            System.out.println(obj.add(a[0],a[1],a[2],a[3]));
    }
}