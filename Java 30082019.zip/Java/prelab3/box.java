import java.util.Scanner;
class Box
{
    int l,b,w;
    Box(int l,int b,int w){
        this.l=l;
        this.b=b;
        this.w=w;
    }
    public  int volume()
    {
        return l*b*w;
    }

}
class MainBox{
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        System.out.println("Enter the length breadth and height");
        Box a=new Box(scan.nextInt(),scan.nextInt(),scan.nextInt());
        System.out.println("Volume="+a.volume());
    }
}