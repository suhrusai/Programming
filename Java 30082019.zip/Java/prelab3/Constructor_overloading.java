class Size{
    int l,b,h,dim;
    Size(int a){
        l=a;
        dim=1;
    }
    Size(int a,int b){
        l=a;
        this.b=b;
        dim=2;
    }
    Size(int a,int b,int c){
        l=a;
        this.b=b;
        h=c;
        dim=3;
    }
}
class Maindim{
    public static void main(String[] args) {
    int a=Integer.parseInt(args[0]);
    Size b= new Size(1);
    if(a==1)
        {
            b=new Size(Integer.parseInt(args[1]));
        }
    else if(a==2)
        {
            b=new Size(Integer.parseInt(args[1]),Integer.parseInt(args[2]));
        }
    else if(a==3)
        {
            b=new Size(Integer.parseInt(args[1]),Integer.parseInt(args[2]),Integer.parseInt(args[3]));
        }
    System.out.println("Number of dimensions="+b.dim);
}
}