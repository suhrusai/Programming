import java.util.Scanner;
class Box{
    int a,b,c;
    Box(int a,int b,int c){
        this.a=a;
        this.b=b;
        this.c=c;
    }
    public Box object(Box a){
        System.out.println("Box dimensions: "+a.a+" "+a.b+" "+a.c);
        return a;
    }
}
class Objectmain{
    public static void main(String[] args) {
        Scanner scan= new Scanner(System.in);
        System.out.print("Enter Box dimensions: ");
        Box a=new Box(scan.nextInt(),scan.nextInt(),scan.nextInt());
        a.object(a);
    }
}